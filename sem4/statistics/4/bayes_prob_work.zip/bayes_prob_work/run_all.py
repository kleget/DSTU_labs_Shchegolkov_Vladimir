import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mpl_cache"))
(ROOT / ".mpl_cache").mkdir(exist_ok=True)
SCRIPTS = [
    "00_prepare_data.py",
    "01_coin_beta_binomial.py",
    "02_linear_regression_book.py",
    "03_robust_anscombe.py",
    "04_hierarchical_regression.py",
    "05_logistic_iris.py",
    "06_prob_prog_book_examples.py",
    "07_prob_prog_tips_ab.py",
]

for name in SCRIPTS:
    print("\n" + "=" * 80)
    print("RUN", name)
    print("=" * 80)
    subprocess.run([sys.executable, str(ROOT / "scripts" / name)], check=True)

print("\nВсе готово: графики лежат в figures, таблицы результатов в results.")
