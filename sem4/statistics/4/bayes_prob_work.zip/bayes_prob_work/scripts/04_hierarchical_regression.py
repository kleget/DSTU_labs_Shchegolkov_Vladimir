import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from utils import RES, save_plot, ols


def shrink(ind, pool, n, k=8):
    # Простая имитация частичного объединения: чем меньше точек, тем сильнее
    # коэффициенты тянутся к общей линии.
    w = n / (n + k)
    return w * ind + (1 - w) * pool


def main():
    rng = np.random.default_rng(314)
    n = 20
    m = 8
    idx = np.repeat(np.arange(m - 1), n)
    idx = np.append(idx, 7)
    a_real = rng.normal(2.5, 0.5, size=m)
    b_real = rng.beta(6, 1, size=m)
    eps = rng.normal(0, 0.5, size=len(idx))
    x = rng.normal(10, 1, len(idx))
    y = a_real[idx] + b_real[idx] * x + eps

    a_pool, b_pool = ols(x, y)
    rows = []
    fig, ax = plt.subplots(2, 4, figsize=(11, 6), sharex=True, sharey=True)
    ax = ax.ravel()
    xg = np.linspace(x.min() - 0.5, x.max() + 0.5, 50)
    for g in range(m):
        mask = idx == g
        xg_i = x[mask]
        yg_i = y[mask]
        if len(xg_i) >= 2:
            a_ind, b_ind = ols(xg_i, yg_i)
        else:
            # Одна точка не определяет прямую, поэтому берем общую линию как старт.
            b_ind = b_pool
            a_ind = yg_i[0] - b_ind * xg_i[0]
        a_sh = shrink(a_ind, a_pool, len(xg_i))
        b_sh = shrink(b_ind, b_pool, len(xg_i))
        ax[g].scatter(xg_i, yg_i)
        ax[g].plot(xg, a_pool + b_pool * xg, color="gray", alpha=0.7, label="общая")
        ax[g].plot(xg, a_sh + b_sh * xg, "k", label="частичное объединение")
        ax[g].set_title(f"группа {g}, n={len(xg_i)}")
        ax[g].set_xlabel("x")
        ax[g].set_ylabel("y")
        ax[g].legend(fontsize=7)
        rows.append({"group": g, "n": len(xg_i), "alpha_shrink": a_sh, "beta_shrink": b_sh,
                     "alpha_ind": a_ind, "beta_ind": b_ind})
    save_plot(fig, "09_hierarchical_regression_shrinkage.png")
    plt.close(fig)

    pd.DataFrame(rows).to_csv(RES / "hierarchical_summary.csv", index=False)
    print(pd.DataFrame(rows).round(3).to_string(index=False))


if __name__ == "__main__":
    main()
