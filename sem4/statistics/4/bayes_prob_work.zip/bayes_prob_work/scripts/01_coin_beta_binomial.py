import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from utils import save_plot, RES


def plot_binomial():
    ns = [1, 2, 4]
    ps = [0.25, 0.5, 0.75]
    x = np.arange(0, max(ns) + 1)
    fig, ax = plt.subplots(len(ns), len(ps), figsize=(8, 7), sharex=True, sharey=True)
    for i, n in enumerate(ns):
        for j, p in enumerate(ps):
            y = stats.binom(n=n, p=p).pmf(x)
            ax[i, j].vlines(x, 0, y, lw=5)
            ax[i, j].set_ylim(0, 1)
            ax[i, j].set_title(f"N={n}, θ={p}")
    ax[-1, 1].set_xlabel("y = число успехов")
    ax[1, 0].set_ylabel("p(y | θ, N)")
    save_plot(fig, "01_binomial_likelihood.png")
    plt.close(fig)


def plot_beta_priors():
    pars = [0.5, 1, 2, 3]
    x = np.linspace(0, 1, 300)
    fig, ax = plt.subplots(4, 4, figsize=(8, 7), sharex=True, sharey=True)
    for i, a in enumerate(pars):
        for j, b in enumerate(pars):
            ax[i, j].plot(x, stats.beta(a, b).pdf(x))
            ax[i, j].set_title(f"α={a}, β={b}", fontsize=8)
    fig.supxlabel("θ")
    fig.supylabel("p(θ)")
    save_plot(fig, "02_beta_priors.png")
    plt.close(fig)


def plot_posteriors():
    n_trials = [0, 1, 2, 3, 4, 8, 16, 32, 50, 150]
    heads =    [0, 1, 1, 1, 1, 4,  6,  9, 13,  48]
    theta_real = 0.35
    priors = [(1, 1), (20, 20), (1, 4)]
    labels = ["Beta(1,1)", "Beta(20,20)", "Beta(1,4)"]
    x = np.linspace(0, 1, 300)

    fig = plt.figure(figsize=(10, 8))
    rows = []
    for i, (n, y) in enumerate(zip(n_trials, heads)):
        ax = fig.add_subplot(4, 3, i + 1 if i else 2)
        for (a, b), lab in zip(priors, labels):
            post_a = a + y
            post_b = b + n - y
            dens = stats.beta(post_a, post_b).pdf(x)
            ax.fill_between(x, 0, dens, alpha=0.35, label=lab)
            mean = post_a / (post_a + post_b)
            lo, hi = stats.beta(post_a, post_b).ppf([0.03, 0.97])
            rows.append({
                "n": n, "heads": y, "prior": lab,
                "post_alpha": post_a, "post_beta": post_b,
                "mean_theta": mean, "hdi_3": lo, "hdi_97": hi,
                "p_theta_gt_0_5": 1 - stats.beta(post_a, post_b).cdf(0.5),
            })
        ax.axvline(theta_real, color="black", lw=1)
        ax.set_xlim(0, 1)
        ax.set_ylim(bottom=0)
        ax.set_title(f"{n} бросков, {y} орлов", fontsize=9)
        if i == 0:
            ax.legend(fontsize=7)
    save_plot(fig, "03_coin_posteriors.png")
    plt.close(fig)

    pd.DataFrame(rows).to_csv(RES / "coin_posteriors.csv", index=False)


def main():
    plot_binomial()
    plot_beta_priors()
    plot_posteriors()
    print("coin: готово")


if __name__ == "__main__":
    main()
