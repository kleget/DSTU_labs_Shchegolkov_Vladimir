import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from utils import save_plot, RES


def bayes_lin_draws(x, y, draws=3000, seed=12):
    rng = np.random.default_rng(seed)
    X = np.c_[np.ones(len(x)), x]
    b = np.linalg.lstsq(X, y, rcond=None)[0]
    y_hat = X @ b
    res = y - y_hat
    dof = len(y) - 2
    s2 = (res @ res) / dof
    cov = s2 * np.linalg.inv(X.T @ X)
    coefs = rng.multivariate_normal(b, cov, size=draws)
    sig = np.sqrt(dof * s2 / rng.chisquare(dof, size=draws))
    return coefs[:, 0], coefs[:, 1], sig


def main():
    np.random.seed(1)
    n = 100
    a_real = 2.5
    b_real = 0.9
    eps = np.random.normal(0, 0.5, size=n)
    x = np.random.normal(10, 1, n)
    y_real = a_real + b_real * x
    y = y_real + eps

    fig, ax = plt.subplots(1, 2, figsize=(9, 4))
    ax[0].plot(x, y, ".")
    ax[0].plot(x, y_real, "k", label="истинная линия")
    ax[0].set_xlabel("x")
    ax[0].set_ylabel("y")
    ax[0].legend()
    ax[1].hist(y, bins=20, density=True, alpha=0.75)
    ax[1].set_xlabel("y")
    ax[1].set_title("распределение y")
    save_plot(fig, "04_book_linear_data.png")
    plt.close(fig)

    a_draw, b_draw, sig_draw = bayes_lin_draws(x, y)
    a_m = a_draw.mean()
    b_m = b_draw.mean()
    x_grid = np.linspace(x.min(), x.max(), 100)

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(x, y, ".", label="данные")
    for a, b in zip(a_draw[::100], b_draw[::100]):
        ax.plot(x_grid, a + b * x_grid, color="gray", alpha=0.2)
    ax.plot(x_grid, a_m + b_m * x_grid, "k", lw=2,
            label=f"средняя линия: y={a_m:.2f}+{b_m:.2f}x")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.legend()
    save_plot(fig, "05_book_linear_posterior_lines.png")
    plt.close(fig)

    mu = a_draw[:, None] + b_draw[:, None] * x_grid[None, :]
    pred = mu + np.random.default_rng(2).normal(0, sig_draw[:, None], size=mu.shape)
    lo_mu, hi_mu = np.quantile(mu, [0.03, 0.97], axis=0)
    lo_y, hi_y = np.quantile(pred, [0.03, 0.97], axis=0)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(x, y, ".")
    ax.plot(x_grid, a_m + b_m * x_grid, "k", label="средний прогноз")
    ax.fill_between(x_grid, lo_y, hi_y, alpha=0.25, label="94% прогнозный интервал")
    ax.fill_between(x_grid, lo_mu, hi_mu, alpha=0.35, label="94% интервал для среднего")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.legend()
    save_plot(fig, "06_book_linear_predictive.png")
    plt.close(fig)

    x_c = x - x.mean()
    a_c, b_c, _ = bayes_lin_draws(x_c, y)
    res = pd.DataFrame([
        {"model": "raw_x", "alpha_mean": a_draw.mean(), "beta_mean": b_draw.mean(),
         "sigma_mean": sig_draw.mean(), "corr_alpha_beta": np.corrcoef(a_draw, b_draw)[0, 1],
         "pearson_r": stats.pearsonr(x, y).statistic},
        {"model": "centered_x", "alpha_mean": a_c.mean(), "beta_mean": b_c.mean(),
         "sigma_mean": np.nan, "corr_alpha_beta": np.corrcoef(a_c, b_c)[0, 1],
         "pearson_r": stats.pearsonr(x, y).statistic},
    ])
    res.to_csv(RES / "linear_regression_summary.csv", index=False)
    print(res.to_string(index=False))


if __name__ == "__main__":
    main()
