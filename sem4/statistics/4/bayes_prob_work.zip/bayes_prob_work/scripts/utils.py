from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIG = ROOT / "figures"
RES = ROOT / "results"
FIG.mkdir(exist_ok=True)
RES.mkdir(exist_ok=True)


def save_plot(fig, name):
    path = FIG / name
    fig.tight_layout()
    fig.savefig(path, dpi=160, bbox_inches="tight")
    return path


def hdi(vals, prob=0.94):
    vals = np.sort(np.asarray(vals))
    n = len(vals)
    k = max(1, int(np.floor(prob * n)))
    wid = vals[k:] - vals[:n-k]
    j = int(np.argmin(wid))
    return float(vals[j]), float(vals[j+k])


def ols(x, y, w=None):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    X = np.c_[np.ones(len(x)), x]
    if w is None:
        b = np.linalg.lstsq(X, y, rcond=None)[0]
    else:
        w = np.asarray(w, dtype=float)
        W = np.sqrt(w)[:, None]
        b = np.linalg.lstsq(X * W, y * W[:, 0], rcond=None)[0]
    return float(b[0]), float(b[1])


def sigmoid(z):
    z = np.clip(z, -40, 40)
    return 1 / (1 + np.exp(-z))


def softmax(z):
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)
