import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.metrics import confusion_matrix

from utils import DATA, RES, save_plot, sigmoid, softmax


def fit_logit(X, y, lr=0.1, steps=6000, reg=0.01):
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    X1 = np.c_[np.ones(len(X)), X]
    b = np.zeros(X1.shape[1])
    for _ in range(steps):
        p = sigmoid(X1 @ b)
        grad = X1.T @ (p - y) / len(y)
        grad[1:] += reg * b[1:]
        b -= lr * grad
    return b


def fit_softmax(X, y, lr=0.2, steps=7000, reg=0.005):
    n, p = X.shape
    k = int(y.max()) + 1
    X1 = np.c_[np.ones(n), X]
    W = np.zeros((p + 1, k))
    Y = np.eye(k)[y]
    for _ in range(steps):
        P = softmax(X1 @ W)
        grad = X1.T @ (P - Y) / n
        grad[1:] += reg * W[1:]
        W -= lr * grad
    return W


def main():
    raw = load_iris(as_frame=True)
    iris = raw.frame.copy()
    iris["species"] = iris["target"].map(dict(enumerate(raw.target_names)))
    iris = iris.drop(columns="target")
    iris.to_csv(DATA / "iris_ready.csv", index=False)

    # Два класса и один признак: setosa vs versicolor, sepal length.
    df = iris[iris["species"].isin(["setosa", "versicolor"])].copy()
    y = (df["species"] == "versicolor").astype(int).to_numpy()
    x_raw = df[["sepal length (cm)"]].to_numpy()
    x_mean = x_raw.mean(axis=0)
    x_std = x_raw.std(axis=0)
    x = (x_raw - x_mean) / x_std
    b = fit_logit(x, y)
    grid_raw = np.linspace(x_raw.min(), x_raw.max(), 200)[:, None]
    grid = (grid_raw - x_mean) / x_std
    p = sigmoid(np.c_[np.ones(len(grid)), grid] @ b)
    bd = x_mean[0] - b[0] * x_std[0] / b[1]

    fig, ax = plt.subplots(figsize=(7, 4))
    jitter = np.random.default_rng(2).normal(0, 0.025, size=len(y))
    ax.scatter(x_raw[:, 0], y + jitter, alpha=0.75)
    ax.plot(grid_raw[:, 0], p, "k", label="P(versicolor | sepal length)")
    ax.axvline(bd, ls="--", label=f"граница ≈ {bd:.2f}")
    ax.set_xlabel("sepal length")
    ax.set_ylabel("класс / вероятность")
    ax.legend()
    save_plot(fig, "10_iris_logistic_1d.png")
    plt.close(fig)

    # Два класса и два признака: граница решения.
    cols = ["sepal length (cm)", "sepal width (cm)"]
    X_raw = df[cols].to_numpy()
    mu = X_raw.mean(axis=0)
    sd = X_raw.std(axis=0)
    X = (X_raw - mu) / sd
    b2 = fit_logit(X, y)
    x1_raw = np.linspace(X_raw[:, 0].min() - 0.2, X_raw[:, 0].max() + 0.2, 100)
    x1 = (x1_raw - mu[0]) / sd[0]
    x2 = -(b2[0] + b2[1] * x1) / b2[2]
    x2_raw = x2 * sd[1] + mu[1]

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X_raw[:, 0], X_raw[:, 1], c=y, alpha=0.8)
    ax.plot(x1_raw, x2_raw, "k", label="граница решения")
    ax.set_xlabel(cols[0])
    ax.set_ylabel(cols[1])
    ax.legend()
    save_plot(fig, "11_iris_logistic_2d_boundary.png")
    plt.close(fig)

    corr = pd.DataFrame(X_raw, columns=cols).corr().abs()
    fig, ax = plt.subplots(figsize=(4, 3))
    im = ax.imshow(corr, vmin=0, vmax=1)
    ax.set_xticks(range(len(cols)), cols, rotation=20)
    ax.set_yticks(range(len(cols)), cols)
    for i in range(len(cols)):
        for j in range(len(cols)):
            ax.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center")
    fig.colorbar(im, ax=ax, label="|corr|")
    save_plot(fig, "12_iris_corr_heatmap.png")
    plt.close(fig)

    # Несбалансированный случай: оставим мало setosa.
    imba = df.iloc[45:].copy()
    y3 = (imba["species"] == "versicolor").astype(int).to_numpy()
    X3_raw = imba[cols].to_numpy()
    mu3 = X3_raw.mean(axis=0)
    sd3 = X3_raw.std(axis=0)
    X3 = (X3_raw - mu3) / sd3
    b3 = fit_logit(X3, y3)
    x1_raw3 = np.linspace(X3_raw[:, 0].min() - 0.2, X3_raw[:, 0].max() + 0.2, 100)
    x1_3 = (x1_raw3 - mu3[0]) / sd3[0]
    x2_3 = -(b3[0] + b3[1] * x1_3) / b3[2]
    x2_raw3 = x2_3 * sd3[1] + mu3[1]
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X3_raw[:, 0], X3_raw[:, 1], c=y3, alpha=0.8)
    ax.plot(x1_raw3, x2_raw3, "k", label="граница при дисбалансе")
    ax.set_xlabel(cols[0])
    ax.set_ylabel(cols[1])
    ax.legend()
    save_plot(fig, "13_iris_imbalanced_boundary.png")
    plt.close(fig)

    # Softmax на всех трех классах и четырех признаках.
    y_all = pd.Categorical(iris["species"]).codes
    X_all = iris[raw.feature_names].to_numpy()
    mu_all = X_all.mean(axis=0)
    sd_all = X_all.std(axis=0)
    Xs = (X_all - mu_all) / sd_all
    W = fit_softmax(Xs, y_all)
    pred = softmax(np.c_[np.ones(len(Xs)), Xs] @ W).argmax(axis=1)
    acc = (pred == y_all).mean()
    cm = confusion_matrix(y_all, pred)
    fig, ax = plt.subplots(figsize=(4.5, 4))
    im = ax.imshow(cm)
    ax.set_xticks(range(3), raw.target_names, rotation=20)
    ax.set_yticks(range(3), raw.target_names)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, cm[i, j], ha="center", va="center")
    ax.set_xlabel("прогноз")
    ax.set_ylabel("истина")
    ax.set_title(f"softmax accuracy = {acc:.2f}")
    fig.colorbar(im, ax=ax)
    save_plot(fig, "14_iris_softmax_confusion.png")
    plt.close(fig)

    # Порождающий классификатор/LDA для одного признака.
    x0 = x_raw[:, 0]
    m0 = x0[y == 0].mean()
    m1 = x0[y == 1].mean()
    bd_lda = (m0 + m1) / 2
    fig, ax = plt.subplots(figsize=(7, 3.5))
    ax.scatter(x0, y + np.random.default_rng(4).normal(0, 0.025, len(y)), alpha=0.7)
    ax.axvline(bd_lda, color="k", ls="--", label=f"LDA граница ≈ {bd_lda:.2f}")
    ax.set_xlabel("sepal length")
    ax.set_ylabel("класс")
    ax.legend()
    save_plot(fig, "15_iris_lda_boundary.png")
    plt.close(fig)

    res = pd.DataFrame([
        {"model": "logistic_1d", "boundary": bd, "accuracy": ((sigmoid(np.c_[np.ones(len(x)), x] @ b) >= 0.5) == y).mean()},
        {"model": "logistic_2d", "boundary": np.nan, "accuracy": ((sigmoid(np.c_[np.ones(len(X)), X] @ b2) >= 0.5) == y).mean()},
        {"model": "softmax_3class", "boundary": np.nan, "accuracy": acc},
        {"model": "lda_1d", "boundary": bd_lda, "accuracy": (((x0 >= bd_lda).astype(int)) == y).mean()},
    ])
    res.to_csv(RES / "iris_logistic_summary.csv", index=False)
    print(res.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
