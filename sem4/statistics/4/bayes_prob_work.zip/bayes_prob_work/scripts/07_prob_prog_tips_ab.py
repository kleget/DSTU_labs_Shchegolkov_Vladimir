import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from utils import DATA, RES, save_plot


def beta_ab(group, conv, name_a, name_b, draws=30000, rng=None):
    rng = np.random.default_rng(1) if rng is None else rng
    a = conv[group == name_a]
    b = conv[group == name_b]
    pa = stats.beta(1 + a.sum(), 1 + len(a) - a.sum())
    pb = stats.beta(1 + b.sum(), 1 + len(b) - b.sum())
    sa = pa.rvs(draws, random_state=rng)
    sb = pb.rvs(draws, random_state=rng)
    return pa, pb, sa, sb


def dirichlet_revenue(vals, group, name, rng, draws=20000):
    # tip buckets: 0, 25, 49, 79 условных денежных единиц.
    cats = pd.cut(vals, [-np.inf, 2, 3, 4, np.inf], labels=[0, 1, 2, 3]).astype(int)
    counts = np.bincount(cats[group == name], minlength=4)
    probs = rng.dirichlet(counts + 1, size=draws)
    money = np.array([0, 25, 49, 79])
    rev = probs @ money
    return counts, probs, rev


def mean_draws(x, rng, draws=20000):
    x = np.asarray(x, dtype=float)
    n = len(x)
    mean = x.mean()
    s2 = x.var(ddof=1)
    sig = np.sqrt((n - 1) * s2 / rng.chisquare(n - 1, size=draws))
    mu = rng.normal(mean, sig / np.sqrt(n), size=draws)
    return mu, sig


def main():
    rng = np.random.default_rng(8)
    tips = pd.read_csv(DATA / "tips_small.csv")
    group = tips["time"].to_numpy()
    conv = (tips["tip_pct"] >= 0.16).astype(int).to_numpy()
    name_a, name_b = "Lunch", "Dinner"

    pa, pb, sa, sb = beta_ab(group, conv, name_a, name_b, rng=rng)
    x = np.linspace(0, 0.65, 400)
    fig, ax = plt.subplots(2, 1, figsize=(8, 7))
    ax[0].plot(x, pa.pdf(x), label=name_a)
    ax[0].plot(x, pb.pdf(x), label=name_b)
    ax[0].set_title("tips_small: конверсия tip_pct >= 16%")
    ax[0].legend()
    lift = (sb - sa) / np.maximum(sa, 1e-9)
    ax[1].hist(lift, bins=60, density=True, alpha=0.8)
    ax[1].axvline(0, color="k", ls="--")
    ax[1].set_title("Относительный рост Dinner против Lunch")
    save_plot(fig, "20_tips_conversion_and_lift.png")
    plt.close(fig)

    cnt_a, prob_a, rev_a = dirichlet_revenue(tips["tip"].to_numpy(), group, name_a, rng)
    cnt_b, prob_b, rev_b = dirichlet_revenue(tips["tip"].to_numpy(), group, name_b, rng)
    diff = rev_b - rev_a
    fig, ax = plt.subplots(2, 1, figsize=(8, 7))
    ax[0].hist(rev_a, bins=50, density=True, alpha=0.7, label=name_a)
    ax[0].hist(rev_b, bins=50, density=True, alpha=0.7, label=name_b)
    ax[0].set_title("Ожидаемая условная выручка по корзинам чаевых")
    ax[0].legend()
    ax[1].hist(diff, bins=50, density=True, alpha=0.8)
    ax[1].axvline(0, color="k", ls="--")
    ax[1].set_title("Разница ожидаемой выручки: Dinner - Lunch")
    save_plot(fig, "21_tips_dirichlet_revenue.png")
    plt.close(fig)

    # BEST-подобный анализ: сравним средний процент чаевых.
    x_a = tips.loc[tips["time"] == name_a, "tip_pct"].to_numpy()
    x_b = tips.loc[tips["time"] == name_b, "tip_pct"].to_numpy()
    mu_a, sd_a = mean_draws(x_a, rng)
    mu_b, sd_b = mean_draws(x_b, rng)
    delta = mu_b - mu_a
    effect = delta / np.sqrt((sd_a ** 2 + sd_b ** 2) / 2)
    fig, ax = plt.subplots(3, 1, figsize=(8, 8))
    ax[0].hist(mu_a, bins=50, density=True, alpha=0.7, label=name_a)
    ax[0].hist(mu_b, bins=50, density=True, alpha=0.7, label=name_b)
    ax[0].set_title("Апостериорные средние tip_pct")
    ax[0].legend()
    ax[1].hist(delta, bins=50, density=True, alpha=0.8)
    ax[1].axvline(0, color="k", ls="--")
    ax[1].set_title("Разница средних: Dinner - Lunch")
    ax[2].hist(effect, bins=50, density=True, alpha=0.8)
    ax[2].axvline(0, color="k", ls="--")
    ax[2].set_title("Размер эффекта")
    save_plot(fig, "22_tips_best_t_test.png")
    plt.close(fig)

    rows = [{
        "n_lunch": int((group == name_a).sum()),
        "n_dinner": int((group == name_b).sum()),
        "p_dinner_better_conv": float((sb > sa).mean()),
        "lift_mean": float(lift.mean()),
        "lift_median": float(np.median(lift)),
        "lift_p30": float(np.percentile(lift, 30)),
        "p_rev_dinner_gt_lunch": float((rev_b > rev_a).mean()),
        "rev_diff_mean": float(diff.mean()),
        "p_tip_pct_dinner_gt_lunch": float((mu_b > mu_a).mean()),
        "tip_pct_delta_mean": float(delta.mean()),
        "effect_mean": float(effect.mean()),
        "counts_lunch_low_mid_high": str(cnt_a.tolist()),
        "counts_dinner_low_mid_high": str(cnt_b.tolist()),
    }]
    pd.DataFrame(rows).to_csv(RES / "tips_prob_prog_summary.csv", index=False)
    print(pd.DataFrame(rows).round(4).to_string(index=False))


if __name__ == "__main__":
    main()
