from pathlib import Path
import pandas as pd

from utils import DATA, RES


def main():
    # Новый датасет меньше 100 строк. Берем известный датасет tips из plotly,
    # затем сохраняем локально, чтобы работа запускалась без интернета.
    import plotly.express as px

    tips = px.data.tips()
    tips = tips.sample(80, random_state=7).reset_index(drop=True)
    tips["tip_pct"] = tips["tip"] / tips["total_bill"]
    tips.to_csv(DATA / "tips_small.csv", index=False)

    info = pd.DataFrame([
        {"dataset": "anscombe", "rows": len(pd.read_csv(DATA / "anscombe.csv")), "source": "uploaded file"},
        {"dataset": "tips_small", "rows": len(tips), "source": "plotly express built-in tips, sampled to <100"},
    ])
    info.to_csv(RES / "data_info.csv", index=False)
    print(info.to_string(index=False))


if __name__ == "__main__":
    main()
