import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import optimize, stats

from utils import RES, save_plot, sigmoid


def ab_demo(rng):
    true_a, true_b = 0.05, 0.04
    n_a, n_b = 1500, 750
    obs_a = rng.binomial(1, true_a, n_a)
    obs_b = rng.binomial(1, true_b, n_b)
    post_a = stats.beta(1 + obs_a.sum(), 1 + n_a - obs_a.sum())
    post_b = stats.beta(1 + obs_b.sum(), 1 + n_b - obs_b.sum())
    sa = post_a.rvs(20000, random_state=rng)
    sb = post_b.rvs(20000, random_state=rng)
    delta = sa - sb

    x = np.linspace(0, 0.12, 400)
    fig, ax = plt.subplots(2, 1, figsize=(8, 7))
    ax[0].plot(x, post_a.pdf(x), label="p_A")
    ax[0].plot(x, post_b.pdf(x), label="p_B")
    ax[0].set_title("A/B: апостериорные вероятности конверсии")
    ax[0].legend()
    ax[1].hist(delta, bins=50, density=True, alpha=0.8)
    ax[1].axvline(0, color="k", ls="--")
    ax[1].set_title("delta = p_A - p_B")
    save_plot(fig, "16_prob_prog_ab_conversion.png")
    plt.close(fig)
    return {"ab_p_a_gt_b": float((sa > sb).mean()), "ab_obs_a": int(obs_a.sum()), "ab_obs_b": int(obs_b.sum())}


def cheating_demo():
    n = 100
    yes = 35
    grid = np.linspace(0, 1, 2000)
    p_yes = 0.5 * grid + 0.25
    log_like = stats.binom.logpmf(yes, n, p_yes)
    post = np.exp(log_like - log_like.max())
    post = post / np.trapz(post, grid)
    mean = np.trapz(grid * post, grid)
    cdf = np.cumsum(post)
    cdf = cdf / cdf[-1]
    lo = np.interp(0.03, cdf, grid)
    hi = np.interp(0.97, cdf, grid)

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(grid, post)
    ax.axvline(mean, color="k", label=f"среднее ≈ {mean:.2f}")
    ax.axvspan(lo, hi, alpha=0.25, label="94% интервал")
    ax.set_xlabel("p = доля списывавших")
    ax.set_ylabel("плотность")
    ax.set_title("Конфиденциальный опрос: апостериорное распределение p")
    ax.legend()
    save_plot(fig, "17_prob_prog_private_answers.png")
    plt.close(fig)
    return {"cheat_mean": float(mean), "cheat_hdi_3": float(lo), "cheat_hdi_97": float(hi)}


def challenger_demo(rng):
    data = np.array([
        [66,0],[70,1],[69,0],[68,0],[67,0],[72,0],[73,0],[70,0],[57,1],
        [63,1],[70,1],[78,0],[67,0],[53,1],[67,0],[75,0],[70,0],[81,0],
        [76,0],[79,0],[75,1],[76,0],[58,1]
    ], dtype=float)
    t = data[:, 0]
    y = data[:, 1]
    tc = (t - t.mean()) / t.std()
    X = np.c_[np.ones(len(t)), tc]

    def nlp(b):
        z = X @ b
        p = sigmoid(z)
        ll = (y * np.log(p + 1e-12) + (1 - y) * np.log(1 - p + 1e-12)).sum()
        lp = stats.norm.logpdf(b[0], 0, 10) + stats.norm.logpdf(b[1], 0, 10)
        return -(ll + lp)

    fit = optimize.minimize(nlp, [0, -1], method="BFGS")
    b = fit.x
    p = sigmoid(X @ b)
    W = np.diag(p * (1 - p) + 1e-6)
    cov = np.linalg.inv(X.T @ W @ X + np.eye(2) / 100)
    draws = rng.multivariate_normal(b, cov, size=10000)
    grid = np.linspace(30, 85, 200)
    grid_c = (grid - t.mean()) / t.std()
    pg = sigmoid(np.c_[np.ones(len(grid)), grid_c] @ draws.T)
    p31 = sigmoid(np.array([1, (31 - t.mean()) / t.std()]) @ draws.T)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(t, y, s=60, alpha=0.7, label="полеты")
    ax.plot(grid, pg.mean(axis=1), "k", label="средняя вероятность")
    ax.fill_between(grid, *np.quantile(pg, [0.03, 0.97], axis=1), alpha=0.25, label="94% интервал")
    ax.axvline(31, ls="--", label="31°F")
    ax.set_xlabel("температура, °F")
    ax.set_ylabel("P(повреждение)")
    ax.set_title("Challenger: логистическая модель повреждения")
    ax.legend()
    save_plot(fig, "18_prob_prog_challenger_logistic.png")
    plt.close(fig)

    # Separation plot.
    pred = p
    order = np.argsort(pred)
    fig, ax = plt.subplots(figsize=(8, 2.4))
    xs = np.arange(len(y))
    ax.bar(xs, y[order], alpha=0.35, label="факт повреждения")
    ax.plot(xs, pred[order], "k", label="P по модели")
    ax.set_ylim(-0.05, 1.05)
    ax.set_title("Разделительный график")
    ax.legend(fontsize=8)
    save_plot(fig, "19_prob_prog_separation_plot.png")
    plt.close(fig)

    return {"challenger_p31_mean": float(p31.mean()), "challenger_p31_hdi_3": float(np.quantile(p31, 0.03)),
            "challenger_p31_hdi_97": float(np.quantile(p31, 0.97))}


def main():
    rng = np.random.default_rng(42)
    out = {}
    out.update(ab_demo(rng))
    out.update(cheating_demo())
    out.update(challenger_demo(rng))
    pd.DataFrame([out]).to_csv(RES / "prob_prog_book_examples_summary.csv", index=False)
    print(pd.DataFrame([out]).round(4).to_string(index=False))


if __name__ == "__main__":
    main()
