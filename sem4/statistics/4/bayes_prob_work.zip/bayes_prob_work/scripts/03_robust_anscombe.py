import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import optimize, stats

from utils import DATA, RES, save_plot, ols


def huber_fit(x, y, c=1.345, iters=40):
    a, b = ols(x, y)
    for _ in range(iters):
        r = y - (a + b * x)
        med = np.median(r)
        scale = 1.4826 * np.median(np.abs(r - med)) + 1e-8
        w = np.minimum(1, c * scale / (np.abs(r) + 1e-8))
        a, b = ols(x, y, w=w)
    return a, b


def student_t_map(x, y):
    # Вариант из книги: y ~ StudentT(alpha + beta * x_centered, eps, nu).
    x_mean = x.mean()
    xc = x - x_mean

    def nlp(par):
        a, b, log_eps, log_nu_m1 = par
        eps = np.exp(log_eps)
        nu_m1 = np.exp(log_nu_m1)
        nu = 1 + nu_m1
        mu = a + b * xc
        ll = stats.t.logpdf(y, df=nu, loc=mu, scale=eps).sum()
        lp = stats.norm.logpdf(a, y.mean(), 1)
        lp += stats.norm.logpdf(b, 0, 1)
        lp += stats.halfnorm.logpdf(eps, scale=5) + log_eps
        lp += stats.expon.logpdf(nu_m1, scale=29) + log_nu_m1
        return -(ll + lp)

    a0, b0 = ols(xc, y)
    start = np.array([a0, b0, np.log(max(np.std(y - (a0 + b0 * xc)), 0.05)), np.log(10)])
    bounds = [(None, None), (None, None), (np.log(0.01), np.log(20)), (np.log(0.05), np.log(100))]
    fit = optimize.minimize(nlp, start, bounds=bounds, method="L-BFGS-B")
    a_c, b, log_eps, log_nu_m1 = fit.x
    a = a_c - b * x_mean
    return float(a), float(b), float(np.exp(log_eps)), float(1 + np.exp(log_nu_m1)), bool(fit.success)


def main():
    ans = pd.read_csv(DATA / "anscombe.csv")
    groups = sorted(ans["dataset"].unique())

    fig, ax = plt.subplots(2, 2, figsize=(9, 7), sharex=True, sharey=True)
    ax = ax.ravel()
    rows = []
    for k, grp in enumerate(groups):
        part = ans[ans["dataset"] == grp]
        x = part["x"].to_numpy(float)
        y = part["y"].to_numpy(float)
        a_ols, b_ols = ols(x, y)
        a_hub, b_hub = huber_fit(x, y)
        a_t, b_t, eps, nu, ok = student_t_map(x, y)
        xg = np.linspace(x.min() - 0.5, x.max() + 0.5, 100)
        ax[k].scatter(x, y, label=f"набор {grp}")
        ax[k].plot(xg, a_ols + b_ols * xg, label="OLS")
        ax[k].plot(xg, a_hub + b_hub * xg, label="свой Huber")
        ax[k].plot(xg, a_t + b_t * xg, "k--", label="из книги Student-t")
        ax[k].set_title(f"Anscombe {grp}")
        ax[k].set_xlabel("x")
        ax[k].set_ylabel("y")
        ax[k].legend(fontsize=7)
        rows.append({
            "dataset": grp,
            "ols_alpha": a_ols, "ols_beta": b_ols,
            "huber_alpha": a_hub, "huber_beta": b_hub,
            "book_t_alpha": a_t, "book_t_beta": b_t,
            "book_t_eps": eps, "book_t_nu": nu, "book_fit_ok": ok,
        })
    save_plot(fig, "07_anscombe_four_robust_fits.png")
    plt.close(fig)

    part = ans[ans["dataset"] == "III"]
    x = part["x"].to_numpy(float)
    y = part["y"].to_numpy(float)
    a_ols, b_ols = ols(x, y)
    a_hub, b_hub = huber_fit(x, y)
    a_t, b_t, eps, nu, ok = student_t_map(x, y)
    xg = np.linspace(x.min() - 0.5, x.max() + 0.5, 100)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(x, y, s=60)
    ax.plot(xg, a_ols + b_ols * xg, label="неробастная OLS")
    ax.plot(xg, a_hub + b_hub * xg, label="свой Huber")
    ax.plot(xg, a_t + b_t * xg, "k--", label="из книги Student-t")
    ax.set_title("Квартет Энскомба III: промах портит обычную регрессию")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.legend()
    save_plot(fig, "08_anscombe_III_focus.png")
    plt.close(fig)

    pd.DataFrame(rows).to_csv(RES / "robust_anscombe_summary.csv", index=False)
    print(pd.DataFrame(rows).round(4).to_string(index=False))


if __name__ == "__main__":
    main()
