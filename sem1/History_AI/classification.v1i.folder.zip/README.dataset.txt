# classification > 2024-12-09 8:51am
https://universe.roboflow.com/kleget/classification-fbb0w

Provided by a Roboflow user
License: CC BY 4.0

