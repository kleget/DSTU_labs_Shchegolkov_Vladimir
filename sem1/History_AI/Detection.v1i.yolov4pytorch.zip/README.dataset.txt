# Detection > 2024-12-09 8:52am
https://universe.roboflow.com/kleget/detection-cqjpi

Provided by a Roboflow user
License: CC BY 4.0

