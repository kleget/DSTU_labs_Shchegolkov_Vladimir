# segmentation > 2024-12-09 8:47am
https://universe.roboflow.com/kleget/segmentation-lkbzt

Provided by a Roboflow user
License: CC BY 4.0

