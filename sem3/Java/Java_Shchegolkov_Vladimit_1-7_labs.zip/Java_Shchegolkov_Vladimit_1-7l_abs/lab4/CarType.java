package lab4;

public enum CarType {
    SEDAN,
    TRUCK,
    BUS,
    SPECIAL
}
