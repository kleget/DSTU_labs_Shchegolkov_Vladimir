public class Hello {
    public static void main(String[] s) {
        System.out.println("Hello World!");
    }
}