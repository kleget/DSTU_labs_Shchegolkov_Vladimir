package lab7;

public class Task8 {
    public static void main(String[] args) {
        GameFrame.main(args);
    }
}
