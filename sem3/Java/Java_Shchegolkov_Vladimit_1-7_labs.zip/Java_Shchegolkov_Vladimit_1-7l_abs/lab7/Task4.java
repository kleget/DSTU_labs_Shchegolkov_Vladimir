package lab7;

public class Task4 {
    public static void main(String[] args) {
        GraphFrame.main(args);
    }
}
