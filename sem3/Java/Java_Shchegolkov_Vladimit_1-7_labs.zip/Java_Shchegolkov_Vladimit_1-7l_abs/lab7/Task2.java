package lab7;

public class Task2 {
    public static void main(String[] args) {
        Task2ImageViewer.main(args);
    }
}
