package lab7;

public class Task7 {
    public static void main(String[] args) {
        System.out.println("Задание 7: мета-классы/иконки для компонентов (без отдельного окна). Решение в файле TripleLabelPanel(5) и DiceComponent(6)");
    }
}
